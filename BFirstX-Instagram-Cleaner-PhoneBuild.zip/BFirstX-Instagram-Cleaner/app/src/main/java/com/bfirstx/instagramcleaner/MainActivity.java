package com.bfirstx.instagramcleaner;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class MainActivity extends android.app.Activity {
    private static final String PREFS = "bfirstx_cleaner";
    private static final String KEY_ACCOUNTS = "accounts";

    private WebView webView;
    private Spinner accountSpinner;
    private NumberPicker countPicker;
    private NumberPicker delayPicker;
    private TextView statusText;
    private Button startButton;
    private Button stopButton;

    private final List<String> accounts = new ArrayList<>();
    private ArrayAdapter<String> accountAdapter;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean pendingStart = false;
    private String pendingUser = "";
    private int pendingCount = 0;
    private int pendingDelay = 12;

    @SuppressLint({"SetJavaScriptEnabled", "AddJavascriptInterface"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView = findViewById(R.id.webView);
        accountSpinner = findViewById(R.id.accountSpinner);
        countPicker = findViewById(R.id.countPicker);
        delayPicker = findViewById(R.id.delayPicker);
        statusText = findViewById(R.id.statusText);
        startButton = findViewById(R.id.startButton);
        stopButton = findViewById(R.id.stopButton);
        Button addAccountButton = findViewById(R.id.addAccountButton);
        Button openInstagramButton = findViewById(R.id.openInstagramButton);

        loadAccounts();
        accountAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accounts);
        accountSpinner.setAdapter(accountAdapter);

        countPicker.setMinValue(1);
        countPicker.setMaxValue(50);
        countPicker.setValue(10);
        countPicker.setWrapSelectorWheel(false);

        delayPicker.setMinValue(8);
        delayPicker.setMaxValue(30);
        delayPicker.setValue(12);
        delayPicker.setWrapSelectorWheel(false);

        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setUserAgentString(settings.getUserAgentString().replace("; wv", ""));
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);

        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true);

        webView.addJavascriptInterface(new JsBridge(), "BFirstXAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String host = request.getUrl().getHost();
                if (host == null) return true;
                host = host.toLowerCase(Locale.ROOT);
                return !(host.endsWith("instagram.com") || host.endsWith("facebook.com"));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                super.onPageFinished(view, url);
                if (pendingStart && url != null && url.toLowerCase(Locale.ROOT).contains("instagram.com/" + pendingUser.toLowerCase(Locale.ROOT))) {
                    pendingStart = false;
                    handler.postDelayed(() -> injectCleaner(pendingCount, pendingDelay), 2500);
                }
            }
        });

        addAccountButton.setOnClickListener(v -> showAddAccountDialog());
        openInstagramButton.setOnClickListener(v -> {
            setStatus("افتح الحساب وسجّل الدخول يدويًا داخل إنستغرام.", false);
            webView.loadUrl("https://www.instagram.com/");
        });

        startButton.setOnClickListener(v -> prepareStart());
        stopButton.setOnClickListener(v -> stopCleaner());

        if (accounts.isEmpty()) {
            showAddAccountDialog();
        } else {
            webView.loadUrl("https://www.instagram.com/");
        }
    }

    private void showAddAccountDialog() {
        EditText input = new EditText(this);
        input.setHint("username بدون @");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("إضافة حساب")
                .setMessage("أدخل اسم مستخدم إنستغرام فقط. لا تدخل كلمة المرور هنا.")
                .setView(input)
                .setPositiveButton("حفظ", (dialog, which) -> {
                    String user = normalizeUser(input.getText().toString());
                    if (user.isEmpty()) return;
                    if (!accounts.contains(user)) {
                        accounts.add(user);
                        saveAccounts();
                        accountAdapter.notifyDataSetChanged();
                    }
                    accountSpinner.setSelection(accounts.indexOf(user));
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void prepareStart() {
        if (accounts.isEmpty() || accountSpinner.getSelectedItem() == null) {
            Toast.makeText(this, "أضف حسابًا أولًا", Toast.LENGTH_SHORT).show();
            return;
        }

        String user = normalizeUser(accountSpinner.getSelectedItem().toString());
        int count = countPicker.getValue();
        int delay = delayPicker.getValue();

        new AlertDialog.Builder(this)
                .setTitle("تأكيد بدء الإزالة")
                .setMessage("الحساب: @" + user + "\nالعدد: " + count + "\nالفاصل: " + delay + " ثانية\n\nتأكد أنك مسجّل الدخول إلى نفس الحساب داخل نافذة إنستغرام.")
                .setPositiveButton("ابدأ", (d, w) -> startCleaner(user, count, delay))
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void startCleaner(String user, int count, int delay) {
        pendingUser = user;
        pendingCount = count;
        pendingDelay = delay;
        pendingStart = true;
        setStatus("جاري فتح صفحة @" + user + " ...", false);
        webView.loadUrl("https://www.instagram.com/" + user + "/");
    }

    private void injectCleaner(int count, int delaySeconds) {
        String js = "javascript:(function(){" +
                "window.__bfirstStop=false;" +
                "window.__bfirstDone=0;" +
                "const TARGET=" + count + ";" +
                "const DELAY=" + (delaySeconds * 1000L) + ";" +
                "const norm=s=>(s||'').trim().toLowerCase().replace(/\\s+/g,' ');" +
                "const followingLabels=['following','متابَع','متابع','يتابع','متابَعة'];" +
                "const unfollowLabels=['unfollow','إلغاء المتابعة','الغاء المتابعة'];" +
                "function visible(el){if(!el)return false;const r=el.getBoundingClientRect();const st=getComputedStyle(el);return r.width>0&&r.height>0&&st.visibility!=='hidden'&&st.display!=='none';}" +
                "function log(m){try{BFirstXAndroid.log(String(m));}catch(e){}}" +
                "function done(m){try{BFirstXAndroid.done(String(m));}catch(e){}}" +
                "function scrollBox(){const dlg=document.querySelector('[role=dialog]');if(!dlg)return;let best=dlg,ov=0;[dlg,...dlg.querySelectorAll('div')].forEach(x=>{let o=x.scrollHeight-x.clientHeight;if(o>ov){ov=o;best=x;}});best.scrollTop=best.scrollHeight;}" +
                "function findBtn(labels,root=document){return [...root.querySelectorAll('button')].find(b=>visible(b)&&labels.includes(norm(b.innerText)));}" +
                "function startLoop(){log('تم فتح قائمة المتابعة. بدأ التنفيذ.');let timer=setInterval(()=>{if(window.__bfirstStop){clearInterval(timer);done('تم الإيقاف بواسطة المستخدم.');return;}if(window.__bfirstDone>=TARGET){clearInterval(timer);done('اكتمل: '+window.__bfirstDone+' من '+TARGET);return;}const dlg=document.querySelector('[role=dialog]')||document;let b=findBtn(followingLabels,dlg);if(!b){scrollBox();log('جاري تحميل المزيد من الحسابات...');return;}b.scrollIntoView({block:'center'});b.click();setTimeout(()=>{let c=findBtn(unfollowLabels,document);if(c){c.click();window.__bfirstDone++;log('تم إلغاء متابعة '+window.__bfirstDone+' / '+TARGET);setTimeout(scrollBox,900);}else{log('لم يظهر زر التأكيد، سيتم المحاولة مجددًا.');}},1200);},DELAY);}" +
                "function openFollowing(){let a=[...document.querySelectorAll('a[href]')].find(x=>(x.getAttribute('href')||'').includes('/following'));if(a){a.click();log('تم فتح Following...');setTimeout(startLoop,2400);}else{log('لم أجد رابط Following. تأكد من تسجيل الدخول لنفس الحساب.');done('تعذر بدء العملية.');}}" +
                "setTimeout(openFollowing,1200);" +
                "})();";
        webView.evaluateJavascript(js, null);
    }

    private void stopCleaner() {
        pendingStart = false;
        webView.evaluateJavascript("javascript:window.__bfirstStop=true;", null);
        setStatus("تم طلب الإيقاف.", true);
    }

    private void setStatus(String text, boolean ok) {
        statusText.setText(text);
        statusText.setTextColor(ok ? Color.rgb(52, 211, 153) : Color.rgb(248, 250, 252));
    }

    private String normalizeUser(String raw) {
        return raw == null ? "" : raw.trim().replace("@", "").replace("/", "");
    }

    private void loadAccounts() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(KEY_ACCOUNTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String s = normalizeUser(arr.optString(i));
                if (!s.isEmpty() && !accounts.contains(s)) accounts.add(s);
            }
        } catch (JSONException ignored) {}
    }

    private void saveAccounts() {
        JSONArray arr = new JSONArray();
        for (String account : accounts) arr.put(account);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ACCOUNTS, arr.toString()).apply();
    }

    private class JsBridge {
        @JavascriptInterface
        public void log(String message) {
            runOnUiThread(() -> setStatus(message, false));
        }

        @JavascriptInterface
        public void done(String message) {
            runOnUiThread(() -> {
                setStatus(message, true);
                Toast.makeText(MainActivity.this, message, Toast.LENGTH_LONG).show();
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }
}
