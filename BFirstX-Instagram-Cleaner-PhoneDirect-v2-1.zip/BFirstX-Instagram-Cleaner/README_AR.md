# BFirstX Instagram Cleaner V4

نسخة آمنة بدون Accessibility وبدون حفظ كلمة مرور.

تحاول فتح صفحة المستخدم داخل تطبيق Instagram بالترتيب:
1. UrlHandlerActivity مع مسار `_u`.
2. `instagram://user?username=`.
3. رابط Instagram موجه للحزمة.
4. المتصفح كحل أخير.

ملاحظة: Instagram لا يوفر رابطًا عامًا موثوقًا لفتح نافذة Following مباشرة، وقد تغيّر بعض إصدارات التطبيق سلوك الروابط وتفتح الصفحة الرئيسية بدل الملف الشخصي.
