package com.bfirstx.instagramcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.ComponentName;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "bfirstx_cleaner";
    private static final String KEY_ACCOUNTS = "accounts";

    private final List<String> accounts = new ArrayList<>();
    private ArrayAdapter<String> accountAdapter;
    private Spinner accountSpinner;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accountSpinner = findViewById(R.id.accountSpinner);
        statusText = findViewById(R.id.statusText);
        Button addAccountButton = findViewById(R.id.addAccountButton);
        Button openProfileButton = findViewById(R.id.openProfileButton);
        Button openFollowingButton = findViewById(R.id.openFollowingButton);
        Button openInstagramButton = findViewById(R.id.openInstagramButton);

        loadAccounts();
        accountAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accounts);
        accountSpinner.setAdapter(accountAdapter);

        addAccountButton.setOnClickListener(v -> showAddAccountDialog());
        openProfileButton.setOnClickListener(v -> openSelectedProfile());
        openFollowingButton.setOnClickListener(v -> openSelectedFollowing());
        openInstagramButton.setOnClickListener(v -> openInstagramApp());

        statusText.setText("الوضع الآمن مفعّل — لا توجد خدمة وصول أو تحكم تلقائي.");
        if (accounts.isEmpty()) showAddAccountDialog();
    }

    private void showAddAccountDialog() {
        EditText input = new EditText(this);
        input.setHint("username بدون @");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("إضافة حساب")
                .setMessage("أدخل اسم المستخدم فقط. التطبيق لا يطلب كلمة المرور ولا يقرأ جلسة Instagram.")
                .setView(input)
                .setPositiveButton("حفظ", (dialog, which) -> {
                    String user = normalizeUser(input.getText().toString());
                    if (user.isEmpty()) return;
                    if (!accounts.contains(user)) {
                        accounts.add(user);
                        saveAccounts();
                        accountAdapter.notifyDataSetChanged();
                    }
                    accountSpinner.setSelection(accounts.indexOf(user));
                    statusText.setText("تم اختيار @" + user);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private String selectedUser() {
        if (accounts.isEmpty() || accountSpinner.getSelectedItem() == null) return "";
        return normalizeUser(accountSpinner.getSelectedItem().toString());
    }

    private void openSelectedProfile() {
        String user = selectedUser();
        if (user.isEmpty()) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }
        openInstagramProfile(user);
    }

    private void openSelectedFollowing() {
        String user = selectedUser();
        if (user.isEmpty()) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }

        // Instagram does not expose a reliable public deep link that opens the Following sheet.
        // Open the profile as directly as possible, then the user taps Following inside Instagram.
        openInstagramProfile(user);
        Toast.makeText(this, "بعد فتح الصفحة اضغط Following داخل Instagram", Toast.LENGTH_LONG).show();
    }

    private void openInstagramProfile(String user) {
        String safeUser = Uri.encode(user);

        // Strategy 1: explicit Instagram URL handler + legacy _u profile route.
        // This is the strongest app-targeted route on Android and avoids the generic launcher.
        try {
            Intent explicit = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://instagram.com/_u/" + safeUser));
            explicit.setComponent(new ComponentName(
                    "com.instagram.android",
                    "com.instagram.android.activity.UrlHandlerActivity"));
            startActivity(explicit);
            statusText.setText("محاولة فتح @" + user + " مباشرة داخل Instagram.");
            return;
        } catch (Exception ignored) { }

        // Strategy 2: Instagram custom scheme.
        try {
            Intent custom = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("instagram://user?username=" + safeUser));
            custom.setPackage("com.instagram.android");
            startActivity(custom);
            statusText.setText("تم إرسال رابط الحساب @" + user + " إلى Instagram.");
            return;
        } catch (Exception ignored) { }

        // Strategy 3: package-targeted web URL.
        try {
            Intent appWeb = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/_u/" + safeUser));
            appWeb.setPackage("com.instagram.android");
            startActivity(appWeb);
            statusText.setText("تم فتح رابط @" + user + " عبر Instagram.");
            return;
        } catch (Exception ignored) { }

        // Final fallback: browser profile URL.
        try {
            startActivity(new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.instagram.com/" + safeUser + "/")));
            statusText.setText("فتح الحساب في المتصفح لأن Instagram لم يقبل الرابط المباشر.");
        } catch (Exception ignored) {
            Toast.makeText(this, "تعذر فتح حساب Instagram", Toast.LENGTH_LONG).show();
        }
    }

    private void openInstagramApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        if (launch != null) {
            startActivity(launch);
        } else {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")));
        }
    }

    private String normalizeUser(String raw) {
        return raw == null ? "" : raw.trim().replace("@", "").replace("/", "");
    }

    private void loadAccounts() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(KEY_ACCOUNTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String s = normalizeUser(arr.optString(i));
                if (!s.isEmpty() && !accounts.contains(s)) accounts.add(s);
            }
        } catch (JSONException ignored) { }
    }

    private void saveAccounts() {
        JSONArray arr = new JSONArray();
        for (String account : accounts) arr.put(account);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_ACCOUNTS, arr.toString())
                .apply();
    }
}
