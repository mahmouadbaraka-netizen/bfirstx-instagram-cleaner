package com.bfirstx.instagramcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.NumberPicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    public static final String PREFS = "bfirstx_cleaner";
    public static final String KEY_ACCOUNTS = "accounts";
    public static final String KEY_RUNNING = "running";
    public static final String KEY_TARGET = "target";
    public static final String KEY_DELAY = "delay";
    public static final String KEY_DONE = "done";

    private final List<String> accounts = new ArrayList<>();
    private ArrayAdapter<String> accountAdapter;
    private Spinner accountSpinner;
    private NumberPicker countPicker;
    private NumberPicker delayPicker;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accountSpinner = findViewById(R.id.accountSpinner);
        countPicker = findViewById(R.id.countPicker);
        delayPicker = findViewById(R.id.delayPicker);
        statusText = findViewById(R.id.statusText);
        Button addAccountButton = findViewById(R.id.addAccountButton);
        Button openInstagramButton = findViewById(R.id.openInstagramButton);
        Button accessibilityButton = findViewById(R.id.accessibilityButton);
        Button startButton = findViewById(R.id.startButton);
        Button stopButton = findViewById(R.id.stopButton);

        loadAccounts();
        accountAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accounts);
        accountSpinner.setAdapter(accountAdapter);

        countPicker.setMinValue(1);
        countPicker.setMaxValue(50);
        countPicker.setValue(10);
        countPicker.setWrapSelectorWheel(false);

        delayPicker.setMinValue(8);
        delayPicker.setMaxValue(30);
        delayPicker.setValue(12);
        delayPicker.setWrapSelectorWheel(false);

        addAccountButton.setOnClickListener(v -> showAddAccountDialog());
        openInstagramButton.setOnClickListener(v -> openInstagramSelectedAccount());
        accessibilityButton.setOnClickListener(v -> openAccessibilitySettings());
        startButton.setOnClickListener(v -> prepareStart());
        stopButton.setOnClickListener(v -> stopCleaner());

        refreshStatus();
        if (accounts.isEmpty()) showAddAccountDialog();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    private void showAddAccountDialog() {
        EditText input = new EditText(this);
        input.setHint("username بدون @");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("إضافة حساب")
                .setMessage("أدخل اسم المستخدم فقط. لا تدخل كلمة المرور؛ التطبيق يستخدم جلسة تطبيق Instagram الموجودة على الهاتف.")
                .setView(input)
                .setPositiveButton("حفظ", (dialog, which) -> {
                    String user = normalizeUser(input.getText().toString());
                    if (user.isEmpty()) return;
                    if (!accounts.contains(user)) {
                        accounts.add(user);
                        saveAccounts();
                        accountAdapter.notifyDataSetChanged();
                    }
                    accountSpinner.setSelection(accounts.indexOf(user));
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void prepareStart() {
        if (accounts.isEmpty() || accountSpinner.getSelectedItem() == null) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isAccessibilityServiceEnabled(this, CleanerAccessibilityService.class)) {
            new AlertDialog.Builder(this)
                    .setTitle("يلزم تفعيل خدمة الوصول")
                    .setMessage("حتى يعمل التطبيق مع جلسة Instagram المفتوحة على الهاتف بدون تسجيل دخول جديد، فعّل BFirstX Cleaner من إعدادات إمكانية الوصول. يمكنك إيقافها في أي وقت.")
                    .setPositiveButton("فتح الإعدادات", (d, w) -> openAccessibilitySettings())
                    .setNegativeButton("إلغاء", null)
                    .show();
            return;
        }

        String user = normalizeUser(accountSpinner.getSelectedItem().toString());
        int count = countPicker.getValue();
        int delay = delayPicker.getValue();

        new AlertDialog.Builder(this)
                .setTitle("بدء الإزالة")
                .setMessage("الحساب: @" + user + "\nالعدد: " + count + "\nالفاصل: " + delay + " ثانية\n\nسيتم فتح تطبيق Instagram نفسه والاستفادة من الحساب المسجل فيه. إذا لم تُفتح قائمة Following تلقائيًا، اضغط عليها مرة واحدة.")
                .setPositiveButton("ابدأ", (d, w) -> startCleaner(user, count, delay))
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private void startCleaner(String user, int count, int delay) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putBoolean(KEY_RUNNING, true)
                .putInt(KEY_TARGET, count)
                .putInt(KEY_DELAY, delay)
                .putInt(KEY_DONE, 0)
                .apply();

        statusText.setText("بدأت العملية. جاري فتح @" + user + " في تطبيق Instagram...");
        openInstagramProfile(user);
    }

    private void stopCleaner() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_RUNNING, false).apply();
        int done = prefs.getInt(KEY_DONE, 0);
        statusText.setText("تم الإيقاف. المنفذ: " + done);
        Toast.makeText(this, "تم إيقاف الإزالة", Toast.LENGTH_SHORT).show();
    }

    private void openInstagramSelectedAccount() {
        if (accounts.isEmpty() || accountSpinner.getSelectedItem() == null) {
            openInstagramApp();
            return;
        }
        openInstagramProfile(normalizeUser(accountSpinner.getSelectedItem().toString()));
    }

    private void openInstagramProfile(String user) {
        try {
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("instagram://user?username=" + Uri.encode(user)));
            intent.setPackage("com.instagram.android");
            startActivity(intent);
        } catch (Exception e) {
            try {
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/" + Uri.encode(user) + "/"));
                startActivity(intent);
            } catch (Exception ignored) {
                Toast.makeText(this, "تعذر فتح Instagram", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void openInstagramApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage("com.instagram.android");
        if (launch != null) {
            startActivity(launch);
        } else {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")));
        }
    }

    private void openAccessibilitySettings() {
        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
    }

    private void refreshStatus() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean running = prefs.getBoolean(KEY_RUNNING, false);
        int done = prefs.getInt(KEY_DONE, 0);
        int target = prefs.getInt(KEY_TARGET, 0);
        boolean enabled = isAccessibilityServiceEnabled(this, CleanerAccessibilityService.class);

        if (running) {
            statusText.setText("يعمل الآن: " + done + " / " + target + (enabled ? "" : " — خدمة الوصول غير مفعلة"));
        } else {
            statusText.setText(enabled ? "جاهز — خدمة الوصول مفعلة" : "جاهز — فعّل خدمة الوصول قبل البدء");
        }
    }

    private String normalizeUser(String raw) {
        return raw == null ? "" : raw.trim().replace("@", "").replace("/", "");
    }

    private void loadAccounts() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(KEY_ACCOUNTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String s = normalizeUser(arr.optString(i));
                if (!s.isEmpty() && !accounts.contains(s)) accounts.add(s);
            }
        } catch (JSONException ignored) { }
    }

    private void saveAccounts() {
        JSONArray arr = new JSONArray();
        for (String account : accounts) arr.put(account);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_ACCOUNTS, arr.toString()).apply();
    }

    public static boolean isAccessibilityServiceEnabled(Context context, Class<?> serviceClass) {
        String expected = new ComponentName(context, serviceClass).flattenToString();
        String enabled = Settings.Secure.getString(context.getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null) return false;
        for (String item : enabled.split(":")) {
            if (item.equalsIgnoreCase(expected)) return true;
        }
        return false;
    }
}
