package com.bfirstx.instagramcleaner;

import android.accessibilityservice.AccessibilityService;
import android.content.SharedPreferences;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Locale;
import java.util.Set;

public class CleanerAccessibilityService extends AccessibilityService {
    private static final Set<String> FOLLOWING = new HashSet<>(Arrays.asList(
            "following", "متابَع", "متابع", "يتابع", "متابَعة"
    ));
    private static final Set<String> UNFOLLOW = new HashSet<>(Arrays.asList(
            "unfollow", "إلغاء المتابعة", "الغاء المتابعة"
    ));

    private long nextAllowedAction = 0L;
    private boolean waitingForConfirm = false;

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {
        if (event == null || event.getPackageName() == null) return;
        if (!"com.instagram.android".contentEquals(event.getPackageName())) return;

        SharedPreferences prefs = getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE);
        if (!prefs.getBoolean(MainActivity.KEY_RUNNING, false)) return;

        int done = prefs.getInt(MainActivity.KEY_DONE, 0);
        int target = prefs.getInt(MainActivity.KEY_TARGET, 0);
        int delaySeconds = Math.max(8, prefs.getInt(MainActivity.KEY_DELAY, 12));
        if (target <= 0 || done >= target) {
            prefs.edit().putBoolean(MainActivity.KEY_RUNNING, false).apply();
            waitingForConfirm = false;
            return;
        }

        long now = SystemClock.elapsedRealtime();
        if (now < nextAllowedAction) return;

        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;

        try {
            AccessibilityNodeInfo confirm = findExactText(root, UNFOLLOW);
            if (confirm != null && clickNodeOrParent(confirm)) {
                done++;
                prefs.edit().putInt(MainActivity.KEY_DONE, done).apply();
                waitingForConfirm = false;
                nextAllowedAction = now + delaySeconds * 1000L;
                if (done >= target) {
                    prefs.edit().putBoolean(MainActivity.KEY_RUNNING, false).apply();
                }
                return;
            }

            if (waitingForConfirm) {
                nextAllowedAction = now + 1200L;
                return;
            }

            AccessibilityNodeInfo following = findExactText(root, FOLLOWING);
            if (following != null && clickNodeOrParent(following)) {
                waitingForConfirm = true;
                nextAllowedAction = now + 1500L;
            }
        } finally {
            root.recycle();
        }
    }

    private AccessibilityNodeInfo findExactText(AccessibilityNodeInfo root, Set<String> labels) {
        ArrayDeque<AccessibilityNodeInfo> queue = new ArrayDeque<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            AccessibilityNodeInfo node = queue.removeFirst();
            CharSequence text = node.getText();
            CharSequence desc = node.getContentDescription();
            String t = normalize(text);
            String d = normalize(desc);
            if (labels.contains(t) || labels.contains(d)) return AccessibilityNodeInfo.obtain(node);
            for (int i = 0; i < node.getChildCount(); i++) {
                AccessibilityNodeInfo child = node.getChild(i);
                if (child != null) queue.add(child);
            }
        }
        return null;
    }

    private boolean clickNodeOrParent(AccessibilityNodeInfo node) {
        AccessibilityNodeInfo current = node;
        for (int i = 0; i < 6 && current != null; i++) {
            if (current.isClickable() && current.isEnabled() && current.isVisibleToUser()) {
                boolean ok = current.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                if (current != node) current.recycle();
                node.recycle();
                return ok;
            }
            AccessibilityNodeInfo parent = current.getParent();
            if (current != node) current.recycle();
            current = parent;
        }
        node.recycle();
        return false;
    }

    private String normalize(CharSequence text) {
        if (text == null) return "";
        return text.toString().trim().toLowerCase(Locale.ROOT).replaceAll("\\s+", " ");
    }

    @Override
    public void onInterrupt() {
        getSharedPreferences(MainActivity.PREFS, MODE_PRIVATE)
                .edit().putBoolean(MainActivity.KEY_RUNNING, false).apply();
        waitingForConfirm = false;
    }
}
