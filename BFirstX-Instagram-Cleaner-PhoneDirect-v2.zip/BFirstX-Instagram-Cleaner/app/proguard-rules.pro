# No custom ProGuard rules required for this local utility.
