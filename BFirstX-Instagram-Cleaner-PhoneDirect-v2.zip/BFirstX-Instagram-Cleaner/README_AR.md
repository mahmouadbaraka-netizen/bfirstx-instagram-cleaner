# BFirstX Instagram Cleaner — Safe Mode v3

نسخة Android بدون خدمة Accessibility وبدون صلاحية تحكم في تطبيق Instagram.

## ما الذي تفعله؟
- حفظ أسماء الحسابات محليًا.
- فتح الحساب المختار في تطبيق Instagram الرسمي.
- محاولة فتح رابط Following في Instagram، وإن لم يفتحه Instagram مباشرة افتح Following من صفحة الحساب.
- لا تطلب كلمة المرور ولا تنسخ جلسة تسجيل الدخول.

## ملاحظة
بسبب إزالة خدمة Accessibility، لا توجد إزالة متابعة تلقائية. إلغاء المتابعة يتم بتأكيد المستخدم داخل تطبيق Instagram الرسمي.
