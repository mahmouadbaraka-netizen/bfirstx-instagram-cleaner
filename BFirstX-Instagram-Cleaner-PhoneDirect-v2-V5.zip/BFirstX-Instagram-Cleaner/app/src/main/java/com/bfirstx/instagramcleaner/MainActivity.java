package com.bfirstx.instagramcleaner;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.net.Uri;
import android.os.Bundle;
import android.text.InputType;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends Activity {
    private static final String PREFS = "bfirstx_cleaner";
    private static final String KEY_ACCOUNTS = "accounts";
    private static final String INSTAGRAM_PACKAGE = "com.instagram.android";

    private final List<String> accounts = new ArrayList<>();
    private ArrayAdapter<String> accountAdapter;
    private Spinner accountSpinner;
    private TextView statusText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        accountSpinner = findViewById(R.id.accountSpinner);
        statusText = findViewById(R.id.statusText);
        Button addAccountButton = findViewById(R.id.addAccountButton);
        Button guaranteedButton = findViewById(R.id.guaranteedButton);
        Button browserProfileButton = findViewById(R.id.browserProfileButton);
        Button copyButton = findViewById(R.id.copyButton);
        Button openInstagramButton = findViewById(R.id.openInstagramButton);

        loadAccounts();
        accountAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, accounts);
        accountSpinner.setAdapter(accountAdapter);

        addAccountButton.setOnClickListener(v -> showAddAccountDialog());
        guaranteedButton.setOnClickListener(v -> guaranteedInstagramFlow());
        browserProfileButton.setOnClickListener(v -> openProfileInBrowser());
        copyButton.setOnClickListener(v -> copySelectedUser());
        openInstagramButton.setOnClickListener(v -> openInstagramApp());

        statusText.setText("جاهز — بدون Accessibility وبدون كلمة مرور.");
        if (accounts.isEmpty()) showAddAccountDialog();
    }

    private void showAddAccountDialog() {
        EditText input = new EditText(this);
        input.setHint("username بدون @");
        input.setSingleLine(true);
        input.setInputType(InputType.TYPE_CLASS_TEXT);

        new AlertDialog.Builder(this)
                .setTitle("إضافة حساب")
                .setMessage("أدخل اسم المستخدم فقط. لا تتم قراءة كلمة المرور أو جلسة Instagram.")
                .setView(input)
                .setPositiveButton("حفظ", (dialog, which) -> {
                    String user = normalizeUser(input.getText().toString());
                    if (user.isEmpty()) return;
                    if (!accounts.contains(user)) {
                        accounts.add(user);
                        saveAccounts();
                        accountAdapter.notifyDataSetChanged();
                    }
                    accountSpinner.setSelection(accounts.indexOf(user));
                    statusText.setText("تم اختيار @" + user);
                })
                .setNegativeButton("إلغاء", null)
                .show();
    }

    private String selectedUser() {
        if (accounts.isEmpty() || accountSpinner.getSelectedItem() == null) return "";
        return normalizeUser(accountSpinner.getSelectedItem().toString());
    }

    // The reliable flow deliberately avoids Instagram deep links because some Instagram
    // versions ignore them and open the home feed. We copy the username first, then open
    // the official app so the user can paste it into Search with no credentials shared.
    private void guaranteedInstagramFlow() {
        String user = selectedUser();
        if (user.isEmpty()) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }
        copyToClipboard(user);
        Toast.makeText(this,
                "تم نسخ @" + user + " — داخل Instagram اضغط البحث ثم لصق.",
                Toast.LENGTH_LONG).show();
        openInstagramApp();
        statusText.setText("تم نسخ @" + user + " وفتح Instagram الرسمي.");
    }

    private void copySelectedUser() {
        String user = selectedUser();
        if (user.isEmpty()) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }
        copyToClipboard(user);
        statusText.setText("تم نسخ @" + user);
        Toast.makeText(this, "تم نسخ @" + user, Toast.LENGTH_SHORT).show();
    }

    private void copyToClipboard(String user) {
        ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
        if (clipboard != null) {
            clipboard.setPrimaryClip(ClipData.newPlainText("Instagram username", user));
        }
    }

    // Opens the profile in a real browser instead of Instagram. This is the reliable
    // profile-opening path when the Instagram app ignores its undocumented deep links.
    private void openProfileInBrowser() {
        String user = selectedUser();
        if (user.isEmpty()) {
            Toast.makeText(this, "أضف اسم الحساب أولًا", Toast.LENGTH_SHORT).show();
            return;
        }

        Uri profile = Uri.parse("https://www.instagram.com/" + Uri.encode(user) + "/");
        Intent base = new Intent(Intent.ACTION_VIEW, profile);
        base.addCategory(Intent.CATEGORY_BROWSABLE);

        // Prefer a browser handler and explicitly exclude Instagram so it cannot redirect
        // the request back to the home feed.
        List<ResolveInfo> handlers = getPackageManager().queryIntentActivities(base, 0);
        for (ResolveInfo info : handlers) {
            if (info.activityInfo == null) continue;
            String pkg = info.activityInfo.packageName;
            if (pkg == null || INSTAGRAM_PACKAGE.equals(pkg)) continue;
            try {
                Intent browser = new Intent(base);
                browser.setPackage(pkg);
                startActivity(browser);
                statusText.setText("تم فتح @" + user + " في المتصفح.");
                return;
            } catch (Exception ignored) { }
        }

        try {
            startActivity(Intent.createChooser(base, "فتح الحساب في المتصفح"));
            statusText.setText("اختر متصفحًا لفتح @" + user);
        } catch (Exception e) {
            Toast.makeText(this, "تعذر العثور على متصفح", Toast.LENGTH_LONG).show();
        }
    }

    private void openInstagramApp() {
        Intent launch = getPackageManager().getLaunchIntentForPackage(INSTAGRAM_PACKAGE);
        if (launch != null) {
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(launch);
            return;
        }
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/")));
        } catch (Exception e) {
            Toast.makeText(this, "Instagram غير مثبت ولا يوجد متصفح متاح", Toast.LENGTH_LONG).show();
        }
    }

    private String normalizeUser(String raw) {
        if (raw == null) return "";
        String u = raw.trim().replace("@", "").replace("/", "");
        // Instagram usernames are letters, digits, periods and underscores.
        return u.replaceAll("[^A-Za-z0-9._]", "");
    }

    private void loadAccounts() {
        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String raw = prefs.getString(KEY_ACCOUNTS, "[]");
        try {
            JSONArray arr = new JSONArray(raw);
            for (int i = 0; i < arr.length(); i++) {
                String s = normalizeUser(arr.optString(i));
                if (!s.isEmpty() && !accounts.contains(s)) accounts.add(s);
            }
        } catch (JSONException ignored) { }
    }

    private void saveAccounts() {
        JSONArray arr = new JSONArray();
        for (String account : accounts) arr.put(account);
        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                .putString(KEY_ACCOUNTS, arr.toString())
                .apply();
    }
}
